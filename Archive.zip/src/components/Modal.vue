<template>
  <teleport to="body">
    <div class="modal" v-if="showModal">
      <div class="modal-mask" @click="closeModal"></div>
      <div class="modal-wrapper">
        <div class="modal-container">
          <div class="modal-header">
            <h3>{{ title }}</h3>
            <button class="modal-close" @click="closeModal">×</button>
          </div>
          <div class="modal-body">
            <slot></slot>
          </div>
        </div>
      </div>
    </div>
  </teleport>
</template>

<script>
  import { ref } from 'vue';
  

  export default {
    name: 'ModalView',
    props: {
      title: String,
      visible: Boolean,
    },
    setup(props, { emit }) {
      const showModal = ref(props.visible);

      const closeModal = () => {
        showModal.value = false;
        emit('update:visible', false);
      };

      return {
        showModal,
        closeModal,
      };
    },
  };
</script>

<style scoped>
  .modal {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 9999;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .modal-mask {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: rgba(0, 0, 0, 0.5);
  }

  .modal-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
  }

  .modal-container {
    position: relative;
    background-color: #fff;
    border-radius: 4px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.33);
    width: 80%;
    max-width: 640px;
    max-height: 90vh;
    overflow-y: auto;
    margin: 16px;
  }

  .modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px;
    border-bottom: 1px solid #ccc;
  }

  .modal-header h3 {
    margin: 0;
    font-size: 1.2rem;
  }

  .modal-close {
    border: none;
    background-color: transparent;
    font-size: 1.2rem;
    cursor: pointer;
  }

  .modal-body {
    padding: 16px;
  }
</style>
