import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
// 


// import "bootstrap/dist/css/bootstrap.css";
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap-vue/dist/bootstrap-vue.css';
// import "bootstrap/dist/js/bootstrap.min.js";
// import "bootstrap-vue/dist/bootstrap-vue-icons.css";
// import "bootstrap-vue/dist/bootstrap-vue.css"
import {BootstrapVue} from "bootstrap-vue";
// import "bootstrap-vue/dist/bootstrap-vue.js"

const app = createApp(App);
// createApp(App)
// app.use(BootstrapVue);
app.use(store).use(router).mount("#app");
