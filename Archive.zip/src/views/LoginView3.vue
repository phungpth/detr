<template>
  <Form @submit="submit">
    <Field name="firstName" label="First Name" rules="required" />
    <ErrorMessage class="error-message" name="firstName" />
    <Field name="lastName" label="Last Name" rules="required" />
    <ErrorMessage class="error-message" name="lastName" />
    <Field name="email" label="Email" rules="required|email" :message="{ required: 'Trường này là bắt buộc.', email: 'Địa chỉ email không hợp lệ.' }"/>
    <ErrorMessage class="error-message" name="email" />
    <Field name="password" label="Password" type="password" rules="required|min:6" v-model="password"
  
    />
    <ErrorMessage class="error-message" name="password" />
    <Field name="password_confirmation" label="password_confirmation" type="password" v-model="password_confirmation" rules="required|confirmed:@password"
    />
    <ErrorMessage class="error-message" name="password_confirmation" />
    <button type="submit">Submit</button>
  </Form>
</template>

<script>
// import { createApp } from 'vue';
import { defineRule, ErrorMessage, Field, Form, configure } from 'vee-validate';
import { required, email, min, confirmed } from '@vee-validate/rules';
import { localize } from '@vee-validate/i18n';

defineRule('required', required);
defineRule('email', email);
defineRule('min', min);
defineRule('confirmed', confirmed);
configure({
  generateMessage: localize({
    en: {
      fields: {
        password: {
          required: 'Password cannot be empty!',
          max: 'Are you really going to remember that?',
          min: 'Too few, you want to get doxed?'
        }
      }
    }
  })
})
// defineRule('password_confirmation', value => {
//   return [
//     required,
//     confirmed('password')
//   ];
// });

export default {
  name: 'LoginView',
  components: {
    ErrorMessage, Field, Form
  },
  data(){
    return {
      password:'',
      password_confirmation: '',
      myInput:''
    }
  },
  methods: {
    submit() {
      // Handle form submission here
    },
  },
};
</script>
