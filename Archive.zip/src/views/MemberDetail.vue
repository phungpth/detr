<template>
{{id}}
</template>
<script>
export default {
  name: "MemberDetail",
  props: {
    id: {
      type: String,
      required: true
    }
  }
}
</script>
